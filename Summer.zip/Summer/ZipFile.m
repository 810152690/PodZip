//
//  ZipFile.m
//  Zip
//
//  Created by summer on 2017/11/21.
//

#import "ZipFile.h"

@implementation ZipFile

- (void)say{
    NSLog(@"Zip pods");
}

@end
