//
//  ZipFile.h
//  Zip
//
//  Created by summer on 2017/11/21.
//

#import <Foundation/Foundation.h>

@interface ZipFile : NSObject

- (void)say;

@end
